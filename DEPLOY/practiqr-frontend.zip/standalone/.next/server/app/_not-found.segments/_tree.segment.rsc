:HL["/_next/static/chunks/3yv8vrxzfioec.css","style"]
:HL["/_next/static/chunks/0bct4nfmcwuhb.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"BFlONz14EyHxsQ-Y-UyGd"}
