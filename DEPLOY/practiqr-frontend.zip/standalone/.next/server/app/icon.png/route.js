var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]_next_dist_1ce_grm._.js")
R.c("server/chunks/[root-of-the-server]__1_7w40z._.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_1-lsc8h.js")
R.m(915295)
module.exports=R.m(915295).exports
