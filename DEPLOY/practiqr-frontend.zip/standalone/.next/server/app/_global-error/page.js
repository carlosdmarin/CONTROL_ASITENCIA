var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1dky4g0._.js")
R.c("server/chunks/ssr/node_modules_next_dist_esm_build_templates_app-page_19--w_z.js")
R.c("server/chunks/ssr/[root-of-the-server]__0bm426j._.js")
R.c("server/chunks/ssr/node_modules_next_dist_172hvm-._.js")
R.c("server/chunks/ssr/node_modules_next_dist_client_components_builtin_global-error_0-o-goa.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0zi5s8-.js")
R.m(942378)
module.exports=R.m(942378).exports
