globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/BFlONz14EyHxsQ-Y-UyGd/_buildManifest.js",
    "static/BFlONz14EyHxsQ-Y-UyGd/_ssgManifest.js",
    "static/BFlONz14EyHxsQ-Y-UyGd/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/37v5ulr6qjozi.js",
    "static/chunks/3z-oetkpttgun.js",
    "static/chunks/34oyci46fsc5w.js",
    "static/chunks/06j3juy1u5a-6.js",
    "static/chunks/3nc6x0_y5iwnk.js",
    "static/chunks/turbopack-209f5n_49-r24.js"
  ]
};
